using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateEnemy : MonoBehaviour {

    [SerializeField] private GameObject enemy;
    [SerializeField] private GameObject waypointA;
    [SerializeField] private GameObject waypointB;
    [SerializeField] private GameObject waypointC;

    private GameObject[] getCount;
    float count;

    public static bool waypointASpawned;
    public static bool waypointBSpawned;
    public static bool waypointCSpawned;

    void Start() {
        SpawnWaypointA();
        SpawnWaypointB();
        SpawnWaypointC();
    }

    void Update() {
        //below from reference: https://answers.unity.com/questions/625683/how-can-i-count-the-number-of-instances-of-a-tagge.html
        getCount = GameObject.FindGameObjectsWithTag ("Enemy");
        count = getCount.Length;
        
        if (count < 10) {
            SpawnObject();
        }

        if (!waypointASpawned) {
            SpawnWaypointAhRAND();
        }

        if (!waypointBSpawned) {
            SpawnWaypointBhRAND();
        }

        if (!waypointCSpawned) {
            SpawnWaypointChRAND();
        }
    }

    //spawn plane
    private void SpawnObject() {
        
        bool objSpawned = false;
        
        while (!objSpawned) {
            Vector3 objPosition = new Vector3(Random.Range(-150f, 150f), Random.Range(-80f, 80f), 0);
            
            // ensures new object is spawned far enough away
            if ((objPosition - transform.position).magnitude < 3) {
                continue;
            } else {
                objSpawned = true;
                Instantiate(enemy, objPosition, Quaternion.identity);
            }
        }
    }

    //spawn Waypoint A
    private void SpawnWaypointA() {

        Vector3 wayAPosition = new Vector3(50, 50, 0);
        Instantiate(waypointA, wayAPosition, Quaternion.identity);

        waypointASpawned = true;
    }

    private void SpawnWaypointAhRAND() {
        float newX = 50 + Random.Range(-15f, 15f);
        float newY = 50 + Random.Range(-15f, 15f);

        Vector3 wayAPosition = new Vector3(newX, newY, 0);
        Instantiate(waypointA, wayAPosition, Quaternion.identity);

        waypointASpawned = true;
    }

    //spawn Waypoint B
    private void SpawnWaypointB() {

        Vector3 wayBPosition = new Vector3(50, -50, 0);
        Instantiate(waypointB, wayBPosition, Quaternion.identity);

        waypointBSpawned = true;
    }

    private void SpawnWaypointBhRAND() {
        float newX = 50 + Random.Range(-15f, 15f);
        float newY = -50 + Random.Range(-15f, 15f);

        Vector3 wayBPosition = new Vector3(newX, newY, 0);
        Instantiate(waypointB, wayBPosition, Quaternion.identity);

        waypointBSpawned = true;
    }

    //spawn Waypoint B
    private void SpawnWaypointC() {

        Vector3 wayCPosition = new Vector3(-50, 50, 0);
        Instantiate(waypointC, wayCPosition, Quaternion.identity);

        waypointCSpawned = true;
    }

    private void SpawnWaypointChRAND() {
        float newX = -50 + Random.Range(-15f, 15f);
        float newY = 50 + Random.Range(-15f, 15f);

        Vector3 wayCPosition = new Vector3(newX, newY, 0);
        Instantiate(waypointC, wayCPosition, Quaternion.identity);

        waypointCSpawned = true;
    }
}
